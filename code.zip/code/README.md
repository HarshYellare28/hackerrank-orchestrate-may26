# Support RAG Agent

Terminal-based multi-domain support agent for the HackerRank Orchestrate challenge. It reads support tickets, retrieves only from the local `data/` corpus, decides whether to reply or escalate, and writes evaluator-compatible output.

## Quickstart

From the repository root:

```bash
sh code/install.sh
sh code/setup_ollama.sh
. .venv/bin/activate
python code/check_ollama.py
python code/main.py --retriever qdrant --rebuild-index
```

If you are starting from `code.zip`, unzip it into the challenge repository root so the paths look like this:

```text
.
├── code/
├── data/
└── support_tickets/
```

`code.zip` contains the agent implementation and setup files. It does not include the challenge corpus (`data/`) or ticket CSVs (`support_tickets/`), because those are provided by the base repository/evaluator.

The default run reads:

```text
support_tickets/support_tickets.csv
```

and writes:

```text
support_tickets/output.csv
```

## Requirements

- Python 3.9+
- The files in this repository, especially `data/` and `support_tickets/`
- Ollama for the recommended local LLM mode

`code/install.sh` creates `.venv`, installs Python dependencies from `code/requirements.txt`, and creates `.env` from `.env.example` if `.env` does not already exist.

Ollama is not installed through `requirements.txt` because it is a system runtime, not a Python package. `code/setup_ollama.sh` attempts to install Ollama on macOS with Homebrew or on Linux with Ollama's install script, then pulls the default local model:

```text
qwen2.5:1.5b
```

If Ollama is not installed, install it from the Ollama website, then rerun:

```bash
sh code/setup_ollama.sh
```

## Environment

Copy the example file:

```bash
cp .env.example .env
```

Recommended local mode:

```bash
SUPPORT_AGENT_LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5:1.5b
SUPPORT_AGENT_ALLOW_HEURISTIC_FALLBACK=true
```

Optional OpenAI mode, if you have credits:

```bash
SUPPORT_AGENT_LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4.1-mini
SUPPORT_AGENT_ALLOW_HEURISTIC_FALLBACK=true
```

Do not commit `.env`. The repository `.gitignore` excludes it.

## Run Modes

Run the full evaluator CSV:

```bash
python code/main.py --retriever qdrant --rebuild-index
```

Run without rebuilding the existing local Qdrant index:

```bash
python code/main.py --retriever qdrant
```

Run a single ticket directly from the terminal:

```bash
python code/main.py \
  --issue "How do I dispute a charge?" \
  --subject "Dispute charge" \
  --company "Visa"
```

Single-ticket mode is useful for user-provided ad hoc questions and manual demos. It does not write `support_tickets/output.csv`; it prints JSON with the same fields as the output CSV:

```text
status, product_area, response, justification, request_type
```

Use the dependency-free retriever fallback if Qdrant is unavailable:

```bash
python code/main.py --retriever bm25
```

## Additional Features

### User Input Flow

The challenge requires CSV input/output, but this agent also supports direct terminal questions:

```bash
python code/main.py \
  --issue "I want to set up Claude LTI in Canvas for my course." \
  --subject "Canvas LTI setup" \
  --company "Claude"
```

The agent normalizes the input, runs the same retrieval/routing/risk pipeline as CSV mode, and prints one JSON prediction. The `--company` value can be `HackerRank`, `Claude`, `Visa`, `None`, or blank.

### Support Document References

When a grounded answer is generated, the agent appends a support-document reference inside the `response` field:

```text
Reference: https://...
```

This keeps the evaluator schema unchanged while giving a real user a link for more details.

### Pluggable Retrieval

The default retriever is Qdrant local. It persists a local index under:

```text
data/index/qdrant
```

Qdrant is used for the real support corpus and for a separate routing-hints collection. Routing hints help with semantic classification, but generated hints are never passed as answer evidence.

BM25 is available as a dependency-free fallback:

```bash
python code/main.py --retriever bm25
```

### Risk and Escalation

The agent includes deterministic gates for cases where retrieval alone is not enough:

- admin-only user/account changes
- broad outages and all-requests-failing bugs
- fraud, stolen cards, blocked cards, and identity theft
- assessment score and hiring-outcome disputes
- security vulnerability and bug bounty reports
- procurement/security questionnaire requests
- unsafe local system commands
- prompt injection and requests to reveal internal logic
- harmless out-of-scope requests

### Local LLM With Fallback

Ollama is the recommended LLM path for reproducibility without paid credits. OpenAI is supported if an API key is available. With `SUPPORT_AGENT_ALLOW_HEURISTIC_FALLBACK=true`, the agent can still finish runs if the LLM provider is unavailable.

## High-Level Flow

1. Normalize each ticket into a stable internal format.
2. Detect obvious risk and request type using deterministic gates.
3. Route the ticket to HackerRank, Claude, or Visa using company hints, corpus retrieval, and routing hints.
4. Retrieve support evidence from the real local corpus with Qdrant local BM25-style sparse search.
5. Use routing hints only for classification and query expansion, never as final answer evidence.
6. Ask the configured LLM judge to refine routing/answerability decisions, with deterministic fallback enabled when configured.
7. Generate a grounded response from retrieved corpus chunks, or escalate risky/unsupported cases.
8. Validate the output schema and write the required CSV columns.

## Output Contract

The output CSV must contain exactly:

```text
status, product_area, response, justification, request_type
```

Allowed values:

```text
status: replied, escalated
request_type: product_issue, feature_request, bug, invalid
```

Product/support claims must come from `data/`. If the docs do not support a safe answer, the agent should escalate or reply as invalid/out of scope.

## Tests

```bash
python -m unittest discover -s code/tests -p 'test_*.py'
```
